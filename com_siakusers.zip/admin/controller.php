<?php
/**
 * com_siakuser 
 * SIAK Mode User
 * Main Controller
 */
defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

/**
 * com_siakuser base component Cntroller
 */
class SiakuserController extends BaseController
{
    protected $default_view = "users";
}
